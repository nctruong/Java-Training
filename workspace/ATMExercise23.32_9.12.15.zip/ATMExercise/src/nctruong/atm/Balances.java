/**
 * 
 */
package nctruong.atm;

/**
 * @author truong
 *
 */
public class Balances {

	/**
	 * 
	 */
	public Balances() {
		// TODO Auto-generated constructor stub
	}

}

/**
 * 
 */
package nctruong.atm;

/**
 * @author truong
 *
 */
public class Session {

	/**
	 * 
	 */
	public Session() {
		// TODO Auto-generated constructor stub
	}

}

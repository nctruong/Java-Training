package nctruong.atm;

public class Message {

	public Message() {
		// TODO Auto-generated constructor stub
	}

}

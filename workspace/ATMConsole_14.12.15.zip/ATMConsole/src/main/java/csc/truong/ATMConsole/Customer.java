/**
 * 
 */
package csc.truong.ATMConsole;

import java.util.Date;

/**
 * @author truong
 *
 */
public class Customer {

	/**
	 * 
	 */
	private String name;
	private int pin;
	private int actived;
	private float amount;
	private Date validTo;
	
	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	public int getActived() {
		return actived;
	}

	public void setActived(int actived) {
		this.actived = actived;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	public Date getValidTo() {
		return validTo;
	}

	public void setValidTo(Date date) {
		this.validTo = date;
	}
	
	
}
